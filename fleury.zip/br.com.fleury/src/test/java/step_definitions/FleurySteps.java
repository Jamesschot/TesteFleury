package step_definitions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import core.BrowserFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.PaginaInicialPage;
import pages.PaginaUnidadePage;

public class FleurySteps {
	
	pages.PageActions pActions = new pages.PageActions();
	PaginaInicialPage pgInicial = new PaginaInicialPage();
	PaginaUnidadePage pgUnidade = new PaginaUnidadePage();
	
	@Before
	public void setUp() {
		BrowserFactory.abrirNavegador();
	}
	
	
	@Given("que eu esteja no site {string}, na opcao de unidades")
	public void que_eu_esteja_no_site_na_opcao_de_unidades(String site) throws InterruptedException {
	    BrowserFactory.getDriver().get(site);
	    Thread.sleep(5000);
	    pActions.selecionar(pgInicial.getUnidades());
	}

	@When("filtrar a unidade atraves do filtro facilidades, e selecionar a primeira")
	public void filtrar_a_unidade_atraves_do_filtro_facilidades_e_selecionar_a_primeira() throws InterruptedException {
		Thread.sleep(5000);
		pActions.selecionar(pgInicial.getFacilidades());
		WebElement scroll = BrowserFactory.getDriver().findElement(By.id("button-checkbox-select")); scroll.sendKeys(Keys.PAGE_DOWN); 
		Thread.sleep(5000);
		pActions.selecionar(pgInicial.getFacilidades1());
		pActions.selecionar(pgInicial.getDetalhes());
		 
	}

	@Then("validar o nome da unidade")
	public void validar_o_nome_da_unidade() {
	    pActions.validarTitulo(pgUnidade.getValidacao());
	}
	
	@After
	public void TearDown() throws InterruptedException {
		BrowserFactory.fecharNavegador();
		
	}

}
