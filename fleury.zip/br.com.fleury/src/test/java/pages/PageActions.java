package pages;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import core.BrowserFactory;

	//Nessa classe, registramos as ações feitas na pagina web.

public class PageActions {
	public void selecionar (By elemento) {
		BrowserFactory.getDriver().findElement(elemento).click();
		
	}
	
	public void validarTitulo (By elemento) {
		String texto = "Vila Mariana";
		System.out.println(texto);
		String textoEsperado = BrowserFactory.getDriver().findElement(elemento).getText();
		System.out.println(textoEsperado);
		assertEquals(textoEsperado, texto);
	}
	


}
