package pages;

import org.openqa.selenium.By;

public class PaginaUnidadePage {
	
	private By validacao = By.xpath("//h3[contains(text(),'Vila Mariana')]");



	public By getValidacao() {
		return validacao;
	}

}
