package pages;

import org.openqa.selenium.By;

public class PaginaInicialPage {

	private By unidades = By.cssSelector(
			"#gatsby-focus-wrapper > div.client-doctor-headercomponentstyle__DesktopBottomHeaderStyled-owoxoj-2.FjEqa > div > div > div > div > div:nth-child(16)");
	private By facilidades = By.cssSelector(
			"#gatsby-focus-wrapper > div.sc-bdVaJa.gridcomponent__GridStyled-sc-8zg10d-0.fHFDYJ > div.sc-bwzfXH.gridcomponent__RowStyled-sc-8zg10d-1.fqDNCQ > div:nth-child(3) > div.checkbox-selectcomponentstyle__CheckboxSelectWrapperStyled-sc-7ktrvg-0.ijWekg");

	private By facilidades1 = By.cssSelector(
			"div.sc-bdVaJa.gridcomponent__GridStyled-sc-8zg10d-0.fHFDYJ:nth-child(9) div.sc-bwzfXH.gridcomponent__RowStyled-sc-8zg10d-1.fqDNCQ:nth-child(3) div.sc-htpNat.gridcomponent__ColStyled-sc-8zg10d-2.ceJViE:nth-child(3) div.checkbox-selectcomponentstyle__CheckboxSelectWrapperStyled-sc-7ktrvg-0.ijWekg div.animationcomponentstyle__ForcedFade-sc-7lsrx1-1.ebkWHA div.checkbox-selectcomponentstyle__CheckboxSelectScrollStyled-sc-7ktrvg-4.hverji > div.checkbox-fieldcomponentstyle__CheckboxFieldStyled-sc-1mdajsk-0.DRDNI:nth-child(3)");

	private By detalhes = By.id("button-see-on-map-2-vila-mariana");
	
	public By getUnidades() {
		return unidades;
	}

	public By getFacilidades() {
		return (By) facilidades;
	}

	public By getFacilidades1() {
		return facilidades1;
	}
	

	public By getDetalhes() {
		return detalhes;
	}

}
