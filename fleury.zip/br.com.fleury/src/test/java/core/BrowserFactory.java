package core;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserFactory {
	
private static WebDriver driver;

	//Nessa classe, configuramos o navegador que iremos realizar o teste
	
	public static WebDriver getDriver() {
		return driver;
	}
	
	public static void abrirNavegador() {
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	public static void fecharNavegador() {
		driver.quit();
	}
	
	

}
